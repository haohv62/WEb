function xacnhan() {
    if (confirm("Bạn có muốn xoá  không?")) {
        return true;
    } else {
        return false;
    }
}